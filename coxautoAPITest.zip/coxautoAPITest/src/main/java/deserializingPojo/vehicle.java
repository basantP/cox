package deserializingPojo;

import java.util.List;

public class vehicle {
    private Integer vehicleIds;

    public Integer getVehicleIds() {

        return vehicleIds;
    }

    public void setVehicleIds(Integer vehicleIds) {

        this.vehicleIds = vehicleIds;
    }

    @Override public String toString() {

        return "vehicle{" +
                "vehicleIds=" + vehicleIds +
                '}';
    }
}
