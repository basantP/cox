package deserializingPojo;

import java.util.List;

public class vehiclesResponse {
    private List<vehicle> vehicleIds;

    public List<vehicle> getVehicleIds() {

        return vehicleIds;
    }

    public void setVehicleIds(List<vehicle> vehicleIds) {

        this.vehicleIds = vehicleIds;
    }

    @Override public String toString() {

        return "vehiclesResponse{" +
                "vehicleIds=" + vehicleIds +
                '}';
    }
}
