package baseTest;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class BaseTest {
    @BeforeClass
    public void baseTest(){

        RestAssured.baseURI = "https://api.coxauto-interview.com/";
    }
}
