package controllers;

import baseTest.BaseTest;

import deserializingPojo.motorSpecs;
import deserializingPojo.vehiclesResponse;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import java.util.List;

import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.contains;

public class DealersTest extends BaseTest {
    @Test(description = "Get a list of all vehicleids in dataset")
    public void getListOfVehiclesInDataSetTest(){
        Response response = RestAssured.
                           given().
                           when().
                                get("/api/datasetId");
        System.out.println(response.getBody().asString());
        String datasetId = response.path("datasetId");

        System.out.println(datasetId);

        RestAssured.
                                          given().
                                          when().
                                          get("/api/{datasetId}/vehicles",datasetId)
                                  .then()
                                  .statusCode(200)
                                  .body("vehicleIds",notNullValue());

    }
    @Test(description = "Get information about a vehicle for a dataset")
    public void getVehicleInfoTest(){
        Response response = RestAssured.
                                               given().
                                               when().
                                               get("/api/datasetId");
        System.out.println(response.getBody().asString());
        String datasetId = response.path("datasetId");
        System.out.println(datasetId);

        //vehiclesResponse vehiclesList = RestAssured.given().when().get("/api/{datasetId}/vehicles", "kQJMsyDY2Ag").as(vehiclesResponse.class);
        List<Integer> vids = RestAssured.given().when().get("/api/{datasetId}/vehicles", datasetId).then().log().all().log().all()
                .extract().jsonPath().getList("vehicleIds");
        System.out.println(vids.get(0));
        int vehicleVin = vids.get(0);

        RestAssured.given()
                   .when().get("/api/{datasetId}/vehicles/{vehicleid}", datasetId,vids.get(0))
                   .then().log().all().log().all()
                    .statusCode(200)

                    .body("year",notNullValue())
                    .body("make",notNullValue())
                    .body("model",notNullValue());
    }

    @Test(description = "Get information about a vehicle for a dataset")
    public void getVehicleInfoAnddetialsTest(){
        Response response = RestAssured.
                                               given().
                                               when().
                                               get("/api/datasetId");
        System.out.println(response.getBody().asString());
        String datasetId = response.path("datasetId");
        System.out.println(datasetId);

        List<Integer> vids = RestAssured.given().when().get("/api/{datasetId}/vehicles", datasetId).then().log().all().log().all()
                                        .extract().jsonPath().getList("vehicleIds");
        System.out.println(vids.get(0));
        int vehicleVin = vids.get(0);

        motorSpecs motorSpecs = RestAssured.given().when().get("/api/{datasetId}/vehicles/{vehicleid}", datasetId,vids.get(0)).as(motorSpecs.class);

        System.out.println(motorSpecs.getModel());
        System.out.println(motorSpecs.getVehicleId());

    }

}
