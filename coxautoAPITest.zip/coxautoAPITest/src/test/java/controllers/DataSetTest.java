package controllers;

import baseTest.BaseTest;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

public class DataSetTest extends BaseTest {
    @Test
    public void getDataSetId(){
        Response response = RestAssured.
                           given().
                           when().
                                get("/api/datasetId");
        System.out.println(response.getBody().asString());
        int statusCode = response.getStatusCode();
        Assert.assertEquals(statusCode, 200, "Status code is not 200 Success");
    }

}
